#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    int N;
    cin >> N;

    double temp[100];

    int skipped = 0;

    for (int i = 0; i < N; i++) {
        cin >> temp[i];
    }

    cout << "Readings entered : " << N << endl;

    cout << "Valid readings : ";

    for (int i = 0; i < N; i++) {
        if (temp[i] < 0) {
            skipped++;
            continue;
        }

        cout << temp[i] << " ";
    }

    cout << endl;
    cout << "Skipped (errors) : " << skipped << endl;

    for (int i = 0; i < N; i++) {
        if (temp[i] >= 45) {
            cout << "First CRITICAL : Index " << i
                 << " -> " << temp[i] << "°C" << endl;
            break;
        }
    }

    double min = 0, max = 0, sum = 0;
    int validCount = 0;

    for (int i = 0; i < N; i++) {
        if (temp[i] < 0)
            continue;

        if (validCount == 0) {
            min = max = temp[i];
        } else {
            if (temp[i] < min)
                min = temp[i];

            if (temp[i] > max)
                max = temp[i];
        }

        sum += temp[i];
        validCount++;
    }

    double avg = sum / validCount;

    cout << fixed << setprecision(2);
    cout << "Min : " << min
         << "°C Max : " << max
         << "°C Avg : " << avg << "°C" << endl;

    int normal = 0, warning = 0, critical = 0, shutdown = 0;

    for (int i = 0; i < N; i++) {
        if (temp[i] < 0)
            continue;

        if (temp[i] < 30)
            normal++;
        else if (temp[i] < 40)
            warning++;
        else if (temp[i] < 50)
            critical++;
        else
            shutdown++;
    }

    cout << "Normal:" << normal
         << " Warning:" << warning
         << " Critical:" << critical
         << " Shutdown:" << shutdown << endl;

    return 0;
}
