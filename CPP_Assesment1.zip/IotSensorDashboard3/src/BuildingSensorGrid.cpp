#include <iostream>
#include <iomanip>
using namespace std;

int main() {

    double tempOfRoom[3][3];

    // Input temperatures
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            cout << "Enter temperature for Floor "
                 << i + 1 << ", Room " << j + 1 << ": ";
            cin >> tempOfRoom[i][j];
        }
    }

    // Print table
    cout << fixed << setprecision(1);

    cout << "\n\tRoom1\tRoom2\tRoom3" << endl;

    for (int i = 0; i < 3; i++) {
        cout << "Floor " << i + 1 << " : ";

        for (int j = 0; j < 3; j++) {
            cout << "\t" << tempOfRoom[i][j];
        }

        cout << endl;
    }


    // -------------------------------
    // Find Hottest Room
    // -------------------------------

    double hottest = tempOfRoom[0][0];
    int hottestFloor = 0;
    int hottestRoom = 0;

    for (int i = 0; i < 3; i++) {

        for (int j = 0; j < 3; j++) {

            if (tempOfRoom[i][j] > hottest) {
                hottest = tempOfRoom[i][j];
                hottestFloor = i;
                hottestRoom = j;
            }
        }
    }

    cout << "Hottest Room : Floor "
         << hottestFloor + 1
         << ", Room "
         << hottestRoom + 1
         << " -> "
         << hottest
         << "°C" << endl;


    // -------------------------------
    // Find Hottest Floor
    // -------------------------------

    double highestAvg = tempOfRoom[0][0];
    int hottestFloorNo = 0;

    for (int i = 0; i < 3; i++) {

        double sum = 0;

        for (int j = 0; j < 3; j++) {
            sum += tempOfRoom[i][j];
        }

        double avg = sum / 3;

        if (avg > highestAvg) {
            highestAvg = avg;
            hottestFloorNo = i;
        }
    }

    cout << "Hottest Floor : Floor "
         << hottestFloorNo + 1
         << " (avg "
         << setprecision(2)
         << highestAvg
         << "°C)" << endl;


    // -------------------------------
    // Count Warning or Above
    // -------------------------------

    int warningOrAbove = 0;

    for (int i = 0; i < 3; i++) {

        for (int j = 0; j < 3; j++) {

            if (tempOfRoom[i][j] >= 30) {
                warningOrAbove++;
            }
        }
    }

    cout << "Rooms at WARNING or above : "
         << warningOrAbove << endl;


    return 0;
}
